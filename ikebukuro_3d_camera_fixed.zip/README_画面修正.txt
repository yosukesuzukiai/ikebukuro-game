池袋3Dマークハント — カメラ表示修正版

修正内容:
- 3Dカメラの上下ベクトルの符号を修正し、道路と主人公が画面の下に隠れないよう調整
- カメラと主人公の間にある建物を非表示にし、視界を確保
- 取得エラー時の地図サーバーごとの理由表示は維持

動作確認:
- JavaScript構文チェック: 合格
- Chromiumでゲーム開始、Wキー前進、プレビュー描画確認
- 実データを使用した全域検証: 未実施（データがこちらにはありません）

GitHub Pagesへの反映:
1. GitHubの yosukesuzukiai/ikebukuro-game へアクセス
2. 新しい index.html をリポジトリ直下の index.html としてアップロードし、Commit changes
3. 公開ページを再読込（Ctrl+F5）
4. 地図JSONを読み込む → 手元に保存した ikebukuro.json を選択
5. 正常なら「オフラインHTMLを保存」をクリックし、保存されたHTMLを再度 index.html に変更してGitHubへアップロードすれば実地図内蔵版になる

注意: 現在のindex.htmlには池袋の実地図JSONは内蔵されていません。取得したJSONを再インポートしてください。
